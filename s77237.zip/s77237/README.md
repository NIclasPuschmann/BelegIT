URL zur Website: http://www.informatik.htw-dresden.de/~s77237/

Erstellt von Niclas Puschmann s77237

genutzter Browser Google Chrome Version 83.0.4103.97 (Offizieller Build)
(64-Bit) MAC OS

- Progressbar vorhanden aber nicht mit Aufgaben verknüpft
- Statistik funktioniert nur fuer den allgemeinen Teil und nicht fuer Mathe
- webmanifest wurde erfolgreich auf Safari mit dem iPhone getestet
    => "Teilen"-Button in der Leiste unten in der Mitte druecken => zum
    Startbildschirm hinzufuegen 

